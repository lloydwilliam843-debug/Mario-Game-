// ============================================================
//  SUPER MARIO STARTER  –  game.js
//  Sections:
//    1. Canvas setup
//    2. Game state
//    3. Player
//    4. Platforms
//    5. Coins
//    6. Enemies
//    7. Input
//    8. Drawing helpers
//    9. Update logic
//   10. Game loop
// ============================================================

// ── 1. Canvas setup ─────────────────────────────────────────
const canvas = document.getElementById('gameCanvas');
const ctx    = canvas.getContext('2d');
const W = canvas.width;   // 800
const H = canvas.height;  // 400

// ── 2. Game state ────────────────────────────────────────────
let score = 0;
let lives = 3;
let gameState = 'playing'; // 'playing' | 'dead' | 'win'

const GRAVITY    = 0.55;
const GROUND_Y   = H - 48;  // top of the ground strip

// ── 3. Player ────────────────────────────────────────────────
const player = {
  x: 80, y: GROUND_Y - 48,
  w: 36, h: 48,
  vx: 0, vy: 0,
  onGround: false,
  facingRight: true,
  // simple walk animation frame
  frame: 0, frameTimer: 0,
};

function resetPlayer() {
  player.x = 80;
  player.y = GROUND_Y - player.h;
  player.vx = 0;
  player.vy = 0;
  player.onGround = false;
}

// ── 4. Platforms ─────────────────────────────────────────────
// Each platform: { x, y, w, h }
const platforms = [
  // ground
  { x: 0,   y: GROUND_Y, w: W,   h: 48 },
  // floating platforms
  { x: 180, y: 290, w: 110, h: 16 },
  { x: 360, y: 230, w: 110, h: 16 },
  { x: 540, y: 170, w: 110, h: 16 },
  { x: 660, y: 280, w: 100, h: 16 },
  { x: 100, y: 190, w: 90,  h: 16 },
];

// ── 5. Coins ──────────────────────────────────────────────────
let coins = [
  { x: 215, y: 255, r: 10, collected: false },
  { x: 245, y: 255, r: 10, collected: false },
  { x: 390, y: 195, r: 10, collected: false },
  { x: 420, y: 195, r: 10, collected: false },
  { x: 570, y: 135, r: 10, collected: false },
  { x: 600, y: 135, r: 10, collected: false },
  { x: 685, y: 245, r: 10, collected: false },
  { x: 130, y: 155, r: 10, collected: false },
  { x: 400, y: 340, r: 10, collected: false },
  { x: 600, y: 340, r: 10, collected: false },
];
const TOTAL_COINS = coins.length;

function resetCoins() {
  coins.forEach(c => c.collected = false);
}

// ── 6. Enemies ────────────────────────────────────────────────
// Simple Goomba-style enemies that patrol a platform
function makeEnemies() {
  return [
    { x: 200, y: GROUND_Y - 32, w: 32, h: 32, vx: 1.2, minX: 160, maxX: 400, alive: true },
    { x: 370, y: 215,           w: 32, h: 32, vx: 1.0, minX: 360, maxX: 460, alive: true },
    { x: 550, y: 155,           w: 32, h: 32, vx: 0.9, minX: 540, maxX: 640, alive: true },
    { x: 500, y: GROUND_Y - 32, w: 32, h: 32, vx: 1.4, minX: 420, maxX: 620, alive: true },
  ];
}
let enemies = makeEnemies();

// ── 7. Input ─────────────────────────────────────────────────
const keys = {};
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if ((e.code === 'Enter') && gameState !== 'playing') restartGame();
});
window.addEventListener('keyup',  e => { keys[e.code] = false; });

// ── 8. Drawing helpers ───────────────────────────────────────

function drawBackground() {
  // Sky gradient
  const grad = ctx.createLinearGradient(0, 0, 0, GROUND_Y);
  grad.addColorStop(0,   '#5c94fc');
  grad.addColorStop(1,   '#a0c4ff');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, GROUND_Y);

  // Clouds (static decorations)
  drawCloud(120, 60, 70);
  drawCloud(380, 45, 90);
  drawCloud(640, 70, 60);

  // Ground
  ctx.fillStyle = '#6b8c42';
  ctx.fillRect(0, GROUND_Y, W, 8);
  ctx.fillStyle = '#8b5e3c';
  ctx.fillRect(0, GROUND_Y + 8, W, H - GROUND_Y - 8);
}

function drawCloud(cx, cy, size) {
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath();
  ctx.arc(cx,          cy,          size * 0.4, 0, Math.PI * 2);
  ctx.arc(cx + size * 0.35, cy - size * 0.1, size * 0.3, 0, Math.PI * 2);
  ctx.arc(cx - size * 0.35, cy,      size * 0.25, 0, Math.PI * 2);
  ctx.fill();
}

function drawPlatform(p) {
  if (p.h === 48) return; // ground drawn in background
  ctx.fillStyle = '#8b5e3c';
  ctx.fillRect(p.x, p.y, p.w, p.h);
  ctx.fillStyle = '#6b8c42';
  ctx.fillRect(p.x, p.y, p.w, 5);
  // brick pattern
  ctx.fillStyle = '#7a5230';
  for (let bx = p.x; bx < p.x + p.w; bx += 22) {
    ctx.fillRect(bx, p.y + 5, 2, p.h - 5);
  }
}

function drawCoin(c) {
  if (c.collected) return;
  const pulse = 1 + 0.08 * Math.sin(Date.now() / 200);
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.scale(pulse, pulse);
  // outer gold ring
  ctx.beginPath();
  ctx.arc(0, 0, c.r, 0, Math.PI * 2);
  ctx.fillStyle = '#ffd700';
  ctx.fill();
  ctx.strokeStyle = '#b8860b';
  ctx.lineWidth = 2;
  ctx.stroke();
  // inner shine
  ctx.beginPath();
  ctx.arc(-2, -2, c.r * 0.45, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,200,0.6)';
  ctx.fill();
  ctx.restore();
}

function drawEnemy(e) {
  if (!e.alive) return;
  const x = e.x, y = e.y, w = e.w, h = e.h;
  // body – brown mushroom cap
  ctx.fillStyle = '#8B4513';
  ctx.beginPath();
  ctx.arc(x + w / 2, y + h * 0.45, w * 0.55, Math.PI, 0);
  ctx.fill();
  // feet
  ctx.fillStyle = '#4a2800';
  ctx.fillRect(x + 2,      y + h - 10, 10, 10);
  ctx.fillRect(x + w - 12, y + h - 10, 10, 10);
  // eyes
  ctx.fillStyle = '#fff';
  ctx.fillRect(x + 6, y + h * 0.4, 8, 8);
  ctx.fillRect(x + w - 14, y + h * 0.4, 8, 8);
  ctx.fillStyle = '#000';
  // angry eyebrows
  const brow = e.vx > 0 ? 1 : -1;
  ctx.fillRect(x + 7  + brow, y + h * 0.35, 6, 3);
  ctx.fillRect(x + w - 13 + brow, y + h * 0.35, 6, 3);
  ctx.fillRect(x + 8, y + h * 0.43, 4, 4);
  ctx.fillRect(x + w - 12, y + h * 0.43, 4, 4);
}

function drawPlayer() {
  const { x, y, w, h, facingRight } = player;
  ctx.save();
  if (!facingRight) {
    ctx.translate(x + w, y);
    ctx.scale(-1, 1);
    ctx.translate(-w, 0);  // keep drawing at local (0,0)
  } else {
    ctx.translate(x, y);
  }

  // Shoes
  ctx.fillStyle = '#5c3317';
  ctx.fillRect(2, h - 10, 14, 10);
  ctx.fillRect(w - 16, h - 10, 14, 10);

  // Overalls (blue legs)
  ctx.fillStyle = '#1a4fa0';
  ctx.fillRect(4, h - 22, 12, 14);
  ctx.fillRect(w - 16, h - 22, 12, 14);

  // Body (red shirt)
  ctx.fillStyle = '#e8254a';
  ctx.fillRect(3, h - 34, w - 6, 14);

  // Overalls bib
  ctx.fillStyle = '#1a4fa0';
  ctx.fillRect(8, h - 34, w - 16, 10);

  // Head (skin)
  ctx.fillStyle = '#f4a460';
  ctx.fillRect(4, 4, w - 8, h - 36);

  // Hat (red)
  ctx.fillStyle = '#e8254a';
  ctx.fillRect(0,  2, w,     8);   // brim
  ctx.fillRect(4,  -6, w - 8, 12); // top

  // Eye
  ctx.fillStyle = '#000';
  ctx.fillRect(w - 12, 12, 5, 5);

  // Moustache
  ctx.fillStyle = '#5c3317';
  ctx.fillRect(w - 18, 20, 14, 4);
  ctx.fillRect(w - 14, 16, 5,  4);

  ctx.restore();
}

// ── 9. Update logic ──────────────────────────────────────────

function updatePlayer(dt) {
  const speed   = 3.8;
  const jumpVel = -13;

  // Horizontal movement
  if (keys['ArrowLeft']  || keys['KeyA']) { player.vx = -speed; player.facingRight = false; }
  else if (keys['ArrowRight'] || keys['KeyD']) { player.vx =  speed; player.facingRight = true;  }
  else player.vx = 0;

  // Jump
  if ((keys['ArrowUp'] || keys['KeyW'] || keys['Space']) && player.onGround) {
    player.vy = jumpVel;
    player.onGround = false;
  }

  // Gravity
  player.vy += GRAVITY;

  // Move X
  player.x += player.vx;

  // Clamp to canvas
  if (player.x < 0) player.x = 0;
  if (player.x + player.w > W) player.x = W - player.w;

  // Platform collision X (push out)
  for (const p of platforms) {
    if (rectsOverlap(player, p)) {
      if (player.vx > 0) player.x = p.x - player.w;
      if (player.vx < 0) player.x = p.x + p.w;
    }
  }

  // Move Y
  player.y += player.vy;
  player.onGround = false;

  for (const p of platforms) {
    if (rectsOverlap(player, p)) {
      if (player.vy > 0) {
        // Landing on top
        player.y = p.y - player.h;
        player.vy = 0;
        player.onGround = true;
      } else if (player.vy < 0) {
        // Hitting underside
        player.y = p.y + p.h;
        player.vy = 1;
      }
    }
  }

  // Fell into a pit
  if (player.y > H + 50) loseLife();
}

function updateEnemies() {
  for (const e of enemies) {
    if (!e.alive) continue;
    e.x += e.vx;
    if (e.x <= e.minX || e.x + e.w >= e.maxX) e.vx *= -1;

    // Check if player stomps enemy (player falling onto top)
    if (
      player.vy > 0 &&
      rectsOverlap(player, e) &&
      player.y + player.h < e.y + e.h * 0.6
    ) {
      e.alive = false;
      player.vy = -8;
      addScore(200);
    } else if (rectsOverlap(player, e)) {
      loseLife();
    }
  }
}

function updateCoins() {
  for (const c of coins) {
    if (c.collected) continue;
    const dx = player.x + player.w / 2 - c.x;
    const dy = player.y + player.h / 2 - c.y;
    if (Math.sqrt(dx * dx + dy * dy) < c.r + 14) {
      c.collected = true;
      addScore(100);
    }
  }
  // Check win
  if (coins.every(c => c.collected)) {
    gameState = 'win';
    showMessage('YOU WIN! 🎉', 'Press ENTER to play again');
  }
}

function addScore(pts) {
  score += pts;
  document.getElementById('score').textContent = score;
}

function loseLife() {
  lives--;
  document.getElementById('lives').textContent = lives;
  if (lives <= 0) {
    gameState = 'dead';
    showMessage('GAME OVER', 'Press ENTER to play again');
  } else {
    resetPlayer();
  }
}

function showMessage(title, sub) {
  const el = document.getElementById('message');
  document.getElementById('message-title').textContent = title;
  document.getElementById('message-sub').textContent   = sub;
  el.classList.remove('hidden');
}

function hideMessage() {
  document.getElementById('message').classList.add('hidden');
}

function restartGame() {
  score = 0;
  lives = 3;
  document.getElementById('score').textContent = score;
  document.getElementById('lives').textContent = lives;
  resetPlayer();
  resetCoins();
  enemies = makeEnemies();
  gameState = 'playing';
  hideMessage();
}

function rectsOverlap(a, b) {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

// ── 10. Game loop ────────────────────────────────────────────
function gameLoop() {
  // Clear
  ctx.clearRect(0, 0, W, H);

  drawBackground();
  platforms.forEach(drawPlatform);
  coins.forEach(drawCoin);
  enemies.forEach(drawEnemy);
  drawPlayer();

  if (gameState === 'playing') {
    updatePlayer();
    updateEnemies();
    updateCoins();
  }

  requestAnimationFrame(gameLoop);
}

gameLoop();
